#ifndef DOG_HPP
#define DOG_HPP

#include <string>
#include <iostream>
#include <map>
#include "creator.hpp"

using namespace std;

class dog : public Animal {
     public:
     virtual void eat() const; 
     virtual void destroy();
};

class dogCreator : public AnimalCreator {
     public:
          dogCreator();
          Animal *create();
};

#endif
