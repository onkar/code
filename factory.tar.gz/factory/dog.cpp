#include "dog.hpp"
#include <iostream>

using namespace std;
extern void addMap(AnimalCreator *a, string str);

dogCreator theDogCreator;

void eat_extern_dog() {
     cout << "dog is eating" << endl;
}

class proxy {
     public :
          proxy() {
               addMap(&theDogCreator, "dog");
          }
};

proxy p;

Animal * dogCreator::create() {
     cout << "Creating dog" << endl;
     return new dog;
}

void dog :: eat() const{
     cout << "dog is eating ..." << endl;
}

void dog :: destroy() {
     delete this;
     cout << "dog is destroyed" << endl;
}
dogCreator::dogCreator() {
}
