#include "creator.hpp"
#include <iostream>
#include <string>
#include <map>
#include <list>
#include <vector>
#include <unistd.h>
#include <dlfcn.h>
#include <stdlib.h>
#include <cstring>

using namespace std;

map<string, AnimalCreator *, less<string> > AnimalMap;
static unsigned int BUF_SIZE = 1024;

void addMap(AnimalCreator* a, string str) {
     AnimalMap[str] = a;
}

Animal* new_animal(const string &animal_name) {
     AnimalCreator *theAnimalCreator = AnimalMap[animal_name];
     if (!theAnimalCreator) {
          cout << "error: " << animal_name << " not registered" << endl;
          exit(1);
     }
     Animal *theAnimal = theAnimalCreator->create();
     return theAnimal;
}

int main(int argc, char **argv) { 
     char input_buffer[BUF_SIZE];
     int i = 1;
     void *dlib;
     char animal_name[BUF_SIZE];

     if (argc == 1) {
          cout << "USAGE: " << argv[0] << " < one or more object-names to be created by factory >" << endl;
          exit(-1);
     }

     while(i <= argc-1) {
          sprintf(animal_name, "./lib%s.so", argv[i]);
          dlib = dlopen(animal_name, RTLD_NOW | RTLD_GLOBAL);
          if (!dlib) {
               cerr << dlerror() << endl;
               exit(1);
          }
          Animal *a = new_animal(argv[i]);
          i++;
          a->eat();
          a->destroy();
          dlclose(animal_name);
          cout << "___________________________________" << endl;
     }
     return 0;
}
