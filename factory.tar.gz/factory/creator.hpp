#ifndef CREATOR_HPP
#define CREATOR_HPP
#include <iostream>
#include <string>
#include <map>
using namespace std;

class Animal {
     
     public :
          Animal() { }
          virtual void eat() const = 0;
          virtual void destroy() = 0;
          virtual ~Animal() { }
};

class AnimalCreator {
     public :
          AnimalCreator() { }
          virtual Animal *create() = 0;
          virtual ~AnimalCreator() { }
};

typedef Animal* create_animal_t(const string &);
typedef void destroy_animal_t(Animal *);
typedef void eat_animal_t();
#endif
