#include "cat.hpp"
#include <iostream>

using namespace std;
extern void addMap(AnimalCreator *a, string str);

catCreator theCatCreator;

class dummy {
     public :
          dummy() {
               addMap(&theCatCreator, "cat");
          }
};

dummy d;

Animal * catCreator :: create() {
     cout << "Creating cat ..."<< endl;
     return new cat;
}

void cat :: eat() const {
     cout << "Cat is eating" << endl;
}

void cat:: destroy() {
     delete this;
     cout << "cat is destroyed" << endl;
}

catCreator::catCreator() {
}
