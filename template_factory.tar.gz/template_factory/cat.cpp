#include "cat.hpp"
#include <iostream>

using namespace std;

class dummy {
     public :
          dummy() {
               RegisterInFactory<Animal, Cat> registerCat("cat");
          }
};

dummy d;

void Cat :: eat() const {
     cout << "Cat is eating" << endl;
}

void Cat:: destroy() {
     cout << "Cat is destroyed" << endl;
}
