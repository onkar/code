#include "creator.hpp"
#include <iostream>
#include <string>
#include <map>
#include <unistd.h>
#include <dlfcn.h>
#include <stdlib.h>
#include <cstring>

using namespace std;
static unsigned int BUF_SIZE = 1024;

std::auto_ptr<Animal> new_animal(const string &animal_name) {
     GenericFactory<Animal> f = GenericFactory<Animal>::instance();
     return f.create(animal_name);
}

int main(int argc, char **argv) { 
     int i = 1;
     void *dlib;
     char animal_name[BUF_SIZE];

     if (argc == 1) {
          cout << "USAGE: " << argv[0] << " < one or more object-names to be created by factory >" << endl;
          exit(-1);
     }

     while(i <= argc-1) {
          sprintf(animal_name, "./lib%s.so", argv[i]);
          dlib = dlopen(animal_name, RTLD_NOW | RTLD_GLOBAL);
          if (!dlib) {
               cerr << dlerror() << endl;
               exit(1);
          }
          std::auto_ptr<Animal> a = new_animal(argv[i]);
          i++;
          a->eat();
          a->destroy();
          dlclose(dlib);
          cout << "___________________________________" << endl;
     }
     return 0;
}
