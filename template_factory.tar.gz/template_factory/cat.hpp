#ifndef CAT_HPP
#define CAT_HPP

#include <iostream>
#include <string>
#include <map> 
#include "creator.hpp"

using namespace std;

class Cat : public Animal {

     public :
          virtual void eat() const;
          virtual void destroy();
};
#endif

