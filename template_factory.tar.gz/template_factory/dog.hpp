#ifndef DOG_HPP
#define DOG_HPP

#include <string>
#include <iostream>
#include <map>
#include "creator.hpp"

using namespace std;

class Dog : public Animal {
     public:
     virtual void eat() const; 
     virtual void destroy();
};

#endif
