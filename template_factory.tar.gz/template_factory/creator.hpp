#ifndef CREATOR_HPP
#define CREATOR_HPP

#include <iostream>
#include <string>
#include <map>
#include <memory>
#include <cstdlib>

class Animal {
     
     public :
          Animal() { }
          virtual void eat() const = 0;
          virtual void destroy() = 0;
};

template <class Animal, typename ClassIDKey = std::string>
class GenericFactory {
     typedef std::auto_ptr<Animal> (*BaseCreateFn) ();
     typename std::map<ClassIDKey, BaseCreateFn> registry;
     GenericFactory() { }

public:
     static GenericFactory &instance() {
          static GenericFactory g;
          return g;
     }
     void RegCreateFn(const ClassIDKey &class_name, BaseCreateFn fn) {
          registry[class_name] = fn;
     }

     std::auto_ptr<Animal> create(const ClassIDKey &class_name) const {
          std::auto_ptr<Animal> theObject(0);
          typename std::map<ClassIDKey, BaseCreateFn>::const_iterator regEntry = registry.find(class_name);
          if (regEntry != registry.end()) {
               theObject = regEntry->second();
          }
          return theObject;
     }
};

template <class Animal, class DerivedClass, typename ClassIDKey = std::string>
class RegisterInFactory {
     public :
          static std::auto_ptr<Animal> create_instance() {
               return std::auto_ptr<Animal> (new DerivedClass);
          }
          RegisterInFactory(const ClassIDKey &class_id) {
               GenericFactory<Animal>::instance().RegCreateFn(class_id, create_instance);
          }
};
#endif
