#include "dog.hpp"
#include <iostream>

using namespace std;
class proxy {
     public :
          proxy() {
               RegisterInFactory<Animal, Dog> registerDog("dog");
          }
};
proxy p;

void Dog :: eat() const{
     cout << "Dog is eating" << endl;
}

void Dog :: destroy() {
     cout << "Dog is destroyed" << endl;
}
