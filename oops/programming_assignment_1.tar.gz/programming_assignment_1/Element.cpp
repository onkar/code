#include <cstring>
#include <string>
#include "Element.hpp"
#include "Visitor.hpp"
using namespace xml;

Element :: ~Element() {
     for (size_t i= 0; i < node_vector.size(); i++) {
          delete node_vector.at(i);
     }
}

Element :: Element(String &name_, String &nmspace_) : elem_name(name_), elem_nmspace(nmspace_) {
}

const String &Element :: name() const {
     return elem_name;
}

const String &Element :: nmspace_prefix() const {
     return elem_nmspace;
}

const String &Element :: nmspace() const {
     return uri;
}

void Element :: set_uri(const String &uri_) {
     uri = uri_;
}
size_t Element::n_children() const {
     return node_vector.size();
}

const Node * Element::child(size_t i) const {
     return node_vector.at(i);
}

void Element::accept(Visitor *v) const {
     v->start_element_visit(*this);
     for (size_t i = 0; i < this->n_children(); i++) {
          if(Element::is_Element(this->child(i))) {
               const Element *e = Element::to_Element(this->child(i));
               e->accept(v);
          }
          else {
               const Text *t = Text::to_Text(this->child(i));
               v->visit_text(*t);
          }
     }
     v->end_element_visit(*this);
}

bool Element :: is_Element(const Node *node_ptr) {
     const Element *e;
     if (!(e = dynamic_cast<const Element *> (node_ptr))){
          return false;
     }
     else return true;
}

const Element* Element :: to_Element(const Node *node_ptr) {
     if(Element::is_Element(node_ptr)) {
          const Element *e = dynamic_cast<const Element *> (node_ptr);
          return e;
     }
     else 
          return NULL;
}

void Element :: add_children( Node *node_ptr) {
     node_vector.push_back(node_ptr);
}
