#include "Parser.hpp"
#include "Element.hpp"
#include "Text.hpp"
#include <stdlib.h>
#include <assert.h>
#include <string>
#include <stack>
#include <map>

using namespace xml;

Parser :: Parser() {

}

bool ClassComp :: operator () (const String &lhs, const String &rhs) {
     return (lhs < rhs);
}

const Element* Parser::parse(const char *doc, size_t sz) {
     enum {
          OPENING_ANGLE_BRACKET = 1,
          WHITESPACE,
          ELEMENT,
          NAMESPACE,
          URI,
          CONTENT,
          END_TAG,
          CLOSING_ANGLE_BRACKET
     } state = OPENING_ANGLE_BRACKET;

     String t_nmspace;
     String uri;
     int flag = -1, ws_count = 0;
     size_t doc_counter = 0;
     std::stack<String> s;
     std::stack<Element *> element_stack;
     Element *root_ptr = NULL, *root = NULL;
     std::map<String, std::stack<String>, ClassComp> namespace_map;
     bool end_flag = false;

     while(doc_counter != sz) {
          const char ch = doc[doc_counter];
          switch(state) {
               case OPENING_ANGLE_BRACKET:
                    {
                         if (ch == '/') {
                              flag = doc_counter + 1;
                              state = END_TAG;
                         }
                         else if(ch == '<') {
                              flag = doc_counter + 1;
                              state = ELEMENT;
                         }
                         else if(ch == '>') {
                              state = CLOSING_ANGLE_BRACKET;
                         }
                         else if (isalnum(ch)) { 
                              flag = doc_counter;
                              state = ELEMENT;
                         }
                         else {
                              std::cout << "Error in XML < state" << std::endl;
                              abort();
                         }
                         doc_counter ++;
                    }
                    break;

               case ELEMENT:
                    {
                         if (ch == '>') {
                              String element(&doc[flag], doc_counter - flag);
                              String nm, name;
                              std::string temp = std::string(element);
                              std::string::size_type pos = temp.find_first_of(":");

                              if (pos != std::string::npos) {
                                   nm = String(&doc[flag], pos);
                                   name = String(&doc[flag + pos + 1], doc_counter - flag - pos -1);
                              }
                              else {
                                   name = String(&doc[flag + pos + 1], doc_counter - flag);
                              }
                              if (element_stack.empty()) {
                                        root = new Element(name, nm);
                                        element_stack.push(root);
                                   }
                                   else  {
                                        Element *e  = new Element(name, nm);
                                        Element *parent = element_stack.top();
                                        parent->add_children(e);
                                        element_stack.push(e);
                                   }

                                   // find ns in the map. if it is not there,
                                   // set uri else error

                                if (nm.length != 0) {
                                   std::string my_nm = "xmlns:" + std::string(nm);
                                   String s;
                                   s = my_nm;
                                   std::map<String,std::stack<String> >::iterator it1 = namespace_map.find(s);
                                   if ( it1 != namespace_map.end() ) {
                                        Element *e = element_stack.top();
                                        e->set_uri(it1->second.top());
                                   }
                                   else {
                                        std::cout << "Found unbound namespace..." << std::endl;
                                        abort();
                                   }

                              }
                              
                              element= "";
                              state = CLOSING_ANGLE_BRACKET;
                         }

                         else if (isspace(ch)) {
                              String nm, name;
                              String element(&doc[flag], doc_counter - flag);
                              std::string temp = std::string(element);
                              std::string::size_type pos = temp.find_first_of(":");
                              
                              if (pos != std::string::npos) {
                                   nm = String(&doc[flag], pos);
                                   name = String(&doc[flag + pos + 1], doc_counter - flag - pos -1);
                               }

                              else {
                                   name = String(&doc[flag + pos + 1], doc_counter - flag);
                              }

                              if (element_stack.empty()) {
                                        root = new Element(name, nm);
                                        element_stack.push(root);
                                   }
                                   else  {
                                        Element *e = new Element(name, nm);
                                        Element *parent = element_stack.top();
                                        parent->add_children(e);
                                        element_stack.push(e);
                                   }

                              if(nm.length != 0) {
                                   std::string my_nm = "xmlns:" + std::string(nm);
                                   String s;
                                   s = my_nm;
                                   std::map<String,std::stack<String> >::iterator it1 = namespace_map.find(s);
                                   if ( it1 != namespace_map.end() ) {
                                        Element *e = element_stack.top();
                                        e->set_uri(it1->second.top());
                                   }
                                   else {
                                        // set end_flag = true and check it in
                                        // CLOSING_ANGLE_BRACKET state
                                        end_flag = true;
                                   }
                              }
                              element = "";
                              flag = -1;
                              state = WHITESPACE;
                         }
                         else if (isalnum(ch) || (ch == '_') || (ch == ':')) {
                         }
                         else {
                              std::cout << "Error in XML ELEMENT state" << std::endl;
                              abort();
                         }
                         doc_counter ++;
                    }
                    break;

               case WHITESPACE:
                    {
                         if(isalpha(ch)) {
                              flag = doc_counter;
                              state = NAMESPACE;
                         }
                         else if (ch == '>') {
                              state = CLOSING_ANGLE_BRACKET;
                         }
                         else if (isspace(ch)) {
                              // do nothing, just eat the space
                         }
                         else {
                              std::cout << "Error in XML WHITESPACE state" << std::endl;
                              abort();
                         }
                         doc_counter ++;
                    }
                    break;

               case NAMESPACE:
                    {
                         if (ch == '=') {
                              String nmspace(&doc[flag], doc_counter - flag);
                              std::string temp = std::string(nmspace);
                              std::string::size_type pos = temp.find_first_of(":");
                              if (pos != std::string::npos) {
                                   std::string::size_type loc = temp.find("xmlns",0);
                                   if (loc == std::string::npos) {
                                        std::cout << "Error in xml" << std::endl;
                                        exit(1);
                                   }
                                   else {
                                        t_nmspace = String(&doc[flag], doc_counter - flag);
                                   }
                                   nmspace = "";
                                   flag = -1;
                                   state = URI;
                                   // increment to eat the starting quotes
                                   // of a URI
                                   doc_counter ++;
                              }
                         }
                         else if(isalnum(ch) || (ch == '_') || (ch == ':')) {
                         }
                         else {
                              std::cout << "Error in XML NAMESPACE state" << std::endl;
                              abort();
                         }
                         doc_counter ++;
                    }
                    break;

               case URI:
                    {
                         if (flag == -1) {
                              flag = doc_counter;
                         }

                         if (ch == '"') {
                              uri = String(&doc[flag], doc_counter - flag);
                              s.push(uri);
                              String t = s.top();
                              std::map<String,std::stack<String> >::iterator it = namespace_map.begin();
                              std::map<String,std::stack<String> >::iterator it1 = namespace_map.find(t_nmspace);
                              if ( it1 == namespace_map.end() ) {
                                   it = namespace_map.insert(it, std::pair<String,std::stack<String> >(t_nmspace,s));
                                   Element *e = element_stack.top();
                                   e->iterator_vector.push_back(it);
                                   std::string temp = e->nmspace_prefix();
                                   if ( ("xmlns:" + temp) == t_nmspace) {
                                        e->set_uri(uri);
                                        end_flag = false;
                                   }
                              }
                              else {
                                   it1->second.push(uri);
                                   Element *e = element_stack.top();
                                   e->iterator_vector.push_back(it1);
                                   std::string temp = e->nmspace_prefix();
                                   if ( ("xmlns:" + temp) == t_nmspace) {
                                        e->set_uri(uri);
                                        end_flag = false;
                                   }
                              }
                              uri = "";
                              // Patch to handle a extra double quote in URI
                              // field
                              if(isspace(doc[doc_counter + 1])) {
                                   state = WHITESPACE;
                              }
                              else if (doc[doc_counter + 1] == '>') {
                                   doc_counter ++;
                                   state = CLOSING_ANGLE_BRACKET;
                              }
                              else {
                                   std::cout << "Error in XML - URI" << std::endl;
                                   abort();
                              }
                         }
                         else if(ch == '>') {
                              state = CLOSING_ANGLE_BRACKET;
                         }
                         else if(isspace(ch)) {
                              state = WHITESPACE;
                         }
                         else if(isalnum(ch) || ch == ':' || ch == '/' || ch == '.' || ch == '_' || ch == '-') {
                         }
                         else {
                              std::cout << "Error in XML URI state" << std::endl;
                              abort();
                         }
                         doc_counter ++;
                    }
                    break;

               case CLOSING_ANGLE_BRACKET:
                    {
                         if (end_flag) {
                              std::cout << "Error in > state" << std::endl;
                              abort();
                         }
                         if (ch == '<') {
                              state = OPENING_ANGLE_BRACKET;
                         }
                         else {
                              flag = doc_counter;
                              state = CONTENT;
                         }
                         doc_counter ++;
                    }
                    break;

               case CONTENT:
                    {
                         if(ch == '<') {
                              String content(&doc[flag], doc_counter - flag);
                              Element *parent = element_stack.top();
                              Text *t = new Text(content);
                              parent->add_children(t);
                              content = "";
                              flag = doc_counter;
                              state = OPENING_ANGLE_BRACKET;
                         }
                         else {
                         }
                         doc_counter ++;
                    }
                    break;

               case END_TAG:
                    {
                         std::string t;
                         if(isspace(ch)) {
                              ws_count ++;
                         }
                         else if(ch == '>') {
                              String end_tag(&doc[flag], doc_counter - flag - ws_count);
                              ws_count = 0;
                              // Pop the element stack to get the actual element
                              // out 
                              if (!element_stack.empty()) {
                                   root_ptr = element_stack.top();
                                   element_stack.pop();
                                   std::string e_nm = std::string(root_ptr->nmspace_prefix());
                                   std::string e_name = std::string(root_ptr->name());
                                   if(e_nm == "") {
                                        t = e_name;
                                   }
                                   else {
                                        t = e_nm + ":" + e_name;
                                   }
                                   if (t != end_tag) {
                                        std::cout << "error in END_TAG state" << std::endl;
                                        abort();
                                   }

                                   int itr_vector_sz = root_ptr->iterator_vector.size();

                                   for (int i = 0; i < itr_vector_sz; i++) {
                                       (root_ptr->iterator_vector.at(i))->second.pop();

                                       if ( ((root_ptr->iterator_vector.at(i))->second.empty()) ) {
                                            namespace_map.erase(root_ptr->iterator_vector.at(i));
                                       }
                                   }
                              }
                              state = CLOSING_ANGLE_BRACKET;
                         }
                         else {
                         }
                         doc_counter ++;
                    }
                    break;
          }
     }
     if (!element_stack.empty()) {
          std::cout << "Error in XML, element stack is not empty" << std::endl;
          abort();
     }
     assert(root_ptr == root);
     return root_ptr;
}
