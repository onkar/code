#include <cstring>
#include "Text.hpp"

using namespace xml;

Text :: Text(String &content_name){
     content = content_name;
}

Text :: Text(std::string &content_name){
     content = content_name;
}


const String& Text::str() const {
     return content;
}

bool Text::is_Text(const Node *n) {
     const Text *t;
     if (!(t = dynamic_cast<const Text *> (n))){
          return false;
     }
     else return true;
}

const Text* Text::to_Text(const Node *n) {
     if(Text::is_Text(n)) {
          const Text *t = dynamic_cast<const Text *> (n);
          return t;
     }
     else 
          return NULL;
}
