#ifndef MYSTRING_HPP
#define MYSTRING_HPP
#include <iostream>
#include <string>

class String {
     public:
          const char *m_begin;
          const char *m_end;
          int length;
     public:
          String();
          String(const char *, int);
          String(const char * , const char *);
          operator std::string() const;
          String &operator=(const String &);
          String &operator = (const std::string &);
         };

bool operator==(const std::string &, const String &);
bool operator==(const String &, const std::string &);
bool operator!=(const std::string &, const String &);
bool operator!=(const String &, const std::string &);

bool operator==(const char *, const String &);
bool operator==(const String &, const char *);
bool operator!=(const char *, const String &);
bool operator!=(const String &, const char *);
bool operator!=(const String&, const String &);

bool operator < (const String&, const String &);
// Output operator
std::ostream &operator<<(std::ostream &, const String &);
#endif
