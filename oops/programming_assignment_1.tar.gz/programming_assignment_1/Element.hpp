#ifndef ELEMENT_HPP
#define ELEMENT_HPP

#include <iostream>
#include <vector>
#include <map>
#include <stack>
#include "Node.hpp"
#include "mystring.hpp"

namespace xml {
     class Visitor;

class Element : public Node {
     private:
          std::vector<Node *> node_vector;
          String elem_name;
          String elem_nmspace;
          String uri;

     public:
          std::vector <std::map<String, std::stack<String> >::iterator > iterator_vector;

    public:
          Element();
          ~Element();
          Element(String &, String &);
          const String &name() const;
          const String &nmspace() const;
          const String &nmspace_prefix() const;
          size_t n_children() const;
          const Node *child(size_t i) const;
          void accept(Visitor *) const;
          static bool is_Element(const Node *);
          static const Element *to_Element(const Node *);
          void add_children(Node *);
          void set_namespace(const std::string &);
          void set_uri(const String &);
};
}
#endif
