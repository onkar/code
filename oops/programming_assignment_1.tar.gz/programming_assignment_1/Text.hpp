#ifndef TEXT_HPP
#define TEXT_HPP
#include <string>
#include "mystring.hpp"
#include "Node.hpp"

namespace xml {
class Text : public Node {
     private:
          String content;
          
     public:
          Text();
          Text(String &);
          Text(std::string &);
          const String &str() const;
          static bool is_Text(const Node *);
          static const Text *to_Text(const Node *);
};
}

#endif
