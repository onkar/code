#ifndef PARSER_HPP
#define PARSER_HPP
#include "Element.hpp"

namespace xml {
class Parser {
     public:
          Parser();
          const Element *parse(const char *, size_t);
};

class ClassComp {
     public :
         bool  operator () (const String &, const String &);
};
}
#endif
