#include "mystring.hpp"

String :: String() : m_begin(NULL), m_end(NULL), length(0){
}

String :: String(const char *st, int len) {
     m_begin = st;
     m_end = m_begin + len - 1;
     length = m_end - m_begin + 1;
}

String :: String(const char *b, const char *e) {
     m_begin = b;
     m_end = e;
     length = m_end - m_begin + 1;
}

String :: operator std::string() const {
     std::string s = std::string(m_begin, length);
     return s;
}

String& String :: operator = (const String &string_){
     m_begin = string_.m_begin;
     m_end = string_.m_end;
     length = string_.length;
     return *this;
}

String& String :: operator = (const std::string &string_){
     m_begin = &string_[0];
     m_end = &string_[string_.length()];
     length = string_.length();
     return *this;
}

bool operator == (const std::string &s1, const String &s2) {
     const char *p = s1.c_str();
     return (p == s2);
}

bool operator == (const String &s1, const std::string &s2) {
     const char *p = s2.c_str();
     return (p == s1);
}

bool operator != (const std::string &s1 , const String &s2) {
     const char *p = s1.c_str();
     return (p != s2);
}

bool operator != (const String &s1, const std::string &s2) {
     const char *p = s2.c_str();
     return (p != s1);
}

bool operator == (const char *ptr, const String &s_) {
     const char *p1, *p2;

     for (p1 = ptr, p2 = s_.m_begin; (p1 != '\0') && (p2 != (s_.m_end + 1)); p1++, p2++) {
          if (*p1 != *p2) {
               return false;
          }
     }
     if ((*p1 == '\0') && (p2 == (s_.m_end + 1))) {
          return true;
     }

     return false;
}

bool operator == (const String &s_, const char *ptr) {
     return ( ptr == s_ );
}

bool operator != (const char *ptr, const String &s_) {
      return !(ptr == s_);
}

bool operator != (const String &s_, const char *ptr) {
     return !(ptr == s_);
}


bool operator < (const String &f, const String &s) {
     const char *p1, *p2;
     int count = 0;

     if (f.length < s.length) {
          return true;
     }
     else if (f.length > s.length) {
          return false;
     }

     // equal length
     for(p1 = f.m_begin, p2 = s.m_begin; (p1 != (f.m_end + 1)) ; p1++, p2++) {
          if (*p1 > *p2) {
               return false;
          }
          else if (*p1 == *p2) {
               count ++;
               continue;
          }
     }

     // exact same strings
     if (count == f.length) {
          return false;
     }

     else
          return true;
}

bool operator != (const String &s1, const String &s2) {
     std::string a = std::string(s1);
     return (s2 != a.c_str());
}

std::ostream &operator<<(std::ostream &stream, const String &s_) {
     stream << std::string(s_);
     return stream;
}
