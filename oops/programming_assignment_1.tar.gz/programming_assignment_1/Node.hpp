#ifndef NODE_HPP
#define NODE_HPP
namespace xml {
class Node {
     public :
          virtual ~Node() { };
     private:
};
}
#endif
