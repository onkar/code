#ifndef VISITOR_HPP
#define VISITOR_HPP

#include "Text.hpp"
#include "Element.hpp"

namespace xml {
class Visitor {
     public :
          virtual void start_element_visit(const Element &) = 0;
          virtual void end_element_visit(const Element &) = 0;
          virtual void visit_text(const Text &) = 0;
          virtual ~Visitor() { };
};
}
#endif
