#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "List_AnimalPtr.hpp"

void list_delete(List_AnimalPtr *lptr) {
     static int loop_counter = 0;
     while((lptr->next_Animal) != (List_AnimalPtr *)0xBAD) {
          List_AnimalPtr *temp = lptr;
          lptr = lptr->next_Animal;
          if (loop_counter != 0)
          free(temp);
          loop_counter ++;
     }
     free(lptr);
}


int iterator_equal(List_AnimalPtr_Iterator_struct *first, const List_AnimalPtr_Iterator_struct &second) {
     return ((first->listptr) == (second.listptr)) ? 1 : 0;
}
void iterator_next(List_AnimalPtr_Iterator *itr) {
     itr->listptr = itr->listptr->next_Animal;
}

Animal *iterator_dereference(List_AnimalPtr_Iterator_struct *a) {
     return a->listptr->AnimalPtr;
}

List_AnimalPtr_Iterator list_begin (List_AnimalPtr_struct *lptr) {
    List_AnimalPtr_Iterator it;
    it.listptr = lptr;
    it.equal = iterator_equal;
    it.next = iterator_next;
    it.deref = iterator_dereference;
    return it;
}


List_AnimalPtr_Iterator list_end (List_AnimalPtr_struct *lptr) {
     List_AnimalPtr_Iterator itr;
     while(lptr->next_Animal != (List_AnimalPtr*)0xBAD) {
          lptr = lptr->next_Animal;
     }
     itr.listptr = lptr->next_Animal;
     return itr;
}

void list_push_back(List_AnimalPtr *lptr,  Animal *a) {
     if (!(lptr->AnimalPtr)) {
          lptr->AnimalPtr = a;
          lptr->push_back = list_push_back;
          lptr->dtor = list_delete;
          lptr->begin = list_begin;
          lptr->end = list_end;
          //List_AnimalPtr *sentinel = (List_AnimalPtr *)malloc(sizeof(List_AnimalPtr));
          //sentinel = (List_AnimalPtr*)0xBAD;
          List_AnimalPtr *sentinel = (List_AnimalPtr *)0xBAD;
          lptr->next_Animal = sentinel;
     }

     else {
          List_AnimalPtr *save_sentinel;
          List_AnimalPtr *temp = (List_AnimalPtr *) malloc (sizeof(List_AnimalPtr));
          temp->AnimalPtr = a;
          temp->next_Animal = NULL;
          temp->push_back = list_push_back;
          temp->dtor = list_delete;
          temp->begin = list_begin;
          temp->end = list_end;

          List_AnimalPtr *p = lptr;
          while(p->next_Animal != (List_AnimalPtr*)0xBAD) {
               p = p->next_Animal;
          }
          save_sentinel = p->next_Animal;
          p->next_Animal = temp;
          temp->next_Animal = save_sentinel;
     }
}

void List_AnimalPtr_ctor(List_AnimalPtr *list) {
     list->AnimalPtr = NULL;
     list->next_Animal = NULL;
     list->push_back = list_push_back;
     list->dtor = list_delete;
     list->begin = list_begin;
     list->end = list_end;
}
