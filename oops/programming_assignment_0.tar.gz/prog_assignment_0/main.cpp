#include <stdio.h>
#include <assert.h>

#include "Animals.hpp"
#include "List_AnimalPtr.hpp"
#include "DynamicArray.hpp"



struct MyClass {
    int num;
};

// This "instantiates" the template.
// Note that there is no semicolon.
DynamicArray_DEFINE(MyClass)
DynamicArray_DEFINE(int)



int
main() {

    /*
     * Test animals.
     */


    // Creates dog with tag number 1234.
    Animal *a1 = (Animal *) Dog_new(1234);

    // Dog name should be "Dog".
    printf("Dog name: %s\n", a1->name);
    printf("Number of legs: %d\n", a1->number_of_legs);

    // Polymorphism, for Dog must call a different
    // function than for Fish.
    // For Dog, should print exactly "Woof!\n".
    // For Fish, should print exactly "Gurgle!\n".
    a1->play(a1);

    Dog *d = Animal_downcast_Dog(a1); // Must return null if not a Dog.
    printf("%d\n", d->dog_tag_number);  // Derived data member.

    // Derived function member, should print exactly "Fetching...\n".
    // Must be a function pointer that is not in Animal.
    d->fetch(d);

    // Must be able to add Fish without changing any code.

    // Fish name should be "Fish", and should of course
    // have 0 legs.
    Animal *a2 = (Animal *) Fish_new();

    // Polymorphism, for Dog must call a different
    // function than for Fish.
    // For Dog, should print exactly "Woof!\n".
    // For Fish, should print exactly "Gurgle!\n".
    a2->play(a2);

    Fish *f = Animal_downcast_Fish(a2);
    // Derived function member, should print exactly "Swimming...\n".
    // Must be a function pointer that is not in Animal.
    f->swim(f);

    // Uncommenting this line must give a compile time error.
    // Dog *d2 = Animal_downcast_Fish(a2);

    // Downcast of wrong derived type must return null.
    assert(Animal_downcast_Fish(a1) == 0);

    // Dog_new() must have return type of Dog *.
    Dog *d2 = Dog_new(5678);
    ((Animal *) d2)->delet((Animal *) d2);

    /*
     * Test list of animal pointers.
     */

    List_AnimalPtr list;
    List_AnimalPtr_ctor(&list);
    list.push_back(&list, a1);
    list.push_back(&list, a2);

    for (List_AnimalPtr_Iterator it = list.begin(&list);
     !it.equal(&it, list.end(&list)); it.next(&it)) {
        Animal *a = it.deref(&it);
        a->play(a);
    }

    // Must not delete the Animals.
    list.dtor(&list);

    // Note that we cannot use 'delete', because it is a reserved
    // word.  It is a keyword.
    a1->delet(a1);
    a2->delet(a2);

    /*
     * Test dynamic array of MyClass objects.
     */

    MyClass o1, o2;
    o1.num = 1234;
    o2.num = 5678;

    DynamicArray_MyClass *array1 = DynamicArray_MyClass_new();
    assert(array1->size == 0);

    // Size should be 1 now.
    array1->push_back(array1, o1);
    assert(array1->size == 1);
    assert(array1->capacity >= array1->size);

    // Resize the array.
    array1->resize(array1, 10);
    assert(array1->size == 10);
    assert(array1->capacity >= array1->size);

    // Access the object at position 1 (zero-based indexing).
    array1->at(array1, 1) = o2; // Abort if out of range.
    // Uncommenting the line below should give an abort.
    // array1->at(array1, 11) = o2;

    printf("array1[0].num: %d, array1[1].num: %d\n", array1->at(array1, 0).num, array1->at(array1, 1).num);

    // Compute the distance in the array between two objects by
    // subtracting their addresses.
    int distance = &DynamicArray_MyClass_at(array1, 4)
     - &DynamicArray_MyClass_at(array1, 2);
    printf("distance: %d\n", distance);

    // Size still 10 after below.
    DynamicArray_MyClass_reserve(array1, 100);
    assert(array1->size == 10);

    // Should print "DynamicArray_MyClass, 21".
    printf("%s, %d\n", array1->type, (int) sizeof(array1->type));

    array1->delet(array1);

    // Should work in exactly the same way for int.
    DynamicArray_int *array2 = DynamicArray_int_new();
    array2->push_back(array2, 1);
    assert(array2->at(array2, 0) == 1);
    array2->resize(array2, 10);
    array2->reserve(array2, 100);
    array2->delet(array2);

    printf("TEST CODE \n");

    DynamicArray_MyClass *test_array1 = DynamicArray_MyClass_new();
    DynamicArray_int *test_array2 = DynamicArray_int_new();
    assert(test_array1->size == 0);
    assert(test_array2->size == 0);
    MyClass test_o1;
    int iter1 = 10000000;
    for(int i=0; i<iter1; i++)
    {
        test_o1.num = i;
        test_array1->push_back(test_array1, test_o1);
        assert(test_array1->size == (i+1));
        if (test_array1->capacity >= test_array1->size) {
             printf("capacity = %d size = %d \n", test_array1->capacity, test_array1->size);
        }
        assert(test_array1->capacity >= test_array1->size);
        test_array2->push_back(test_array2, i);
        assert(test_array2->size == (i+1));
        assert(test_array2->capacity >= test_array2->size);
    }
    printf("test_array1[%d].num: %d\n",(iter1-1), (test_array1->at(test_array1, (iter1-1))).num);
    printf("test_array2[%d]: %d\n", (iter1-1), test_array2->at(test_array2, (iter1-1)));

    return 0;
}
