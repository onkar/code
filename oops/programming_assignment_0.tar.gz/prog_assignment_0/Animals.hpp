#ifndef ANIMAL_HPP
#define ANIMAL_HPP

struct Animal_struct {
     char *name;
     int number_of_legs;
     void (* play) (Animal_struct *);
     void (* delet) (Animal_struct *);
};

typedef struct Animal_struct Animal;

struct Dog_struct {
     Animal animal;
     int dog_tag_number;
     void (*fetch) (Dog_struct *d);
};

struct Fish_struct {
     Animal animal;
     void (*swim) (Fish_struct *f);
};

typedef struct Dog_struct Dog;
typedef struct Fish_struct Fish;

Dog *Dog_new(int tag_number);
Fish *Fish_new();
Dog* Animal_downcast_Dog(Animal *a);
Fish* Animal_downcast_Fish(Animal *a);

#endif
