#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include "Animals.hpp"


void Dog_play(Animal *a) {
     printf("Woof ! \n");
}

void Fish_play(Animal *a) {
     printf("Gurgle ! \n");
}

void Dog_fetch(Dog *d) {
     printf("Fetching ... \n");
}

void Fish_swim(Fish *f) {
     printf("Swimming ... \n");
}

void Dog_delete(Animal *d) {
     free(d->name);
     free((Dog *)d);
}

void Fish_delete(Animal *f) {
     free(f->name);
     free((Dog *)f);
}

Dog *Dog_new(int tag_number) {
     Dog *ptr = (Dog *) malloc (sizeof(Dog));
     ptr->dog_tag_number = tag_number;
     ptr->animal.number_of_legs = 4;
     ptr->animal.name = (char *) malloc(sizeof(char) * 4);
     strcpy(ptr->animal.name,"Dog"); 
     ptr->animal.play = Dog_play;
     ptr->animal.delet = Dog_delete;
     ptr->fetch = Dog_fetch;
     return ptr;
}

Fish *Fish_new(void) {
     Fish *ptr = (Fish *) malloc (sizeof(Fish));
     ptr->animal.number_of_legs = 0;
     ptr->animal.name = (char *) malloc(sizeof(char) * 5);
     strcpy(ptr->animal.name,"Fish"); 
     ptr->animal.play = Fish_play;
     ptr->animal.delet = Fish_delete;
     ptr->swim = Fish_swim;
     return ptr;
}

Dog* Animal_downcast_Dog(Animal *a) {
     if ( !strcmp(a->name, "Dog") )
          return (Dog*)a;
     else
          return NULL;
}

Fish* Animal_downcast_Fish(Animal *a) {
     if ( !strcmp(a->name, "Fish"))
          return (Fish*)a;
     else 
          return NULL;
}
