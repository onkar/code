#ifndef GENERIC_TEMPLATE_MACRO
#define GENERIC_TEMPLATE_MACRO

#include <stdlib.h>
#include <string.h>

#define DynamicArray_DEFINE(OBJNAME) \
     struct DynamicArray_##OBJNAME { \
          int size; \
          int capacity; \
          char type [sizeof "DynamicArray_"#OBJNAME]; \
          OBJNAME *arr; \
          DynamicArray_##OBJNAME* (*DynamicArray_##OBJNAME##_new)(); \
          void (*push_back)(DynamicArray_##OBJNAME *,OBJNAME); \
          void (*resize)(DynamicArray_##OBJNAME*, int); \
          void (*delet)(DynamicArray_##OBJNAME *); \
          OBJNAME & (*at) (DynamicArray_##OBJNAME *, int); \
          void (*reserve) (DynamicArray_##OBJNAME*, int); \
}; \
OBJNAME & (*DynamicArray_##OBJNAME##_at)(DynamicArray_##OBJNAME *, int); \
void (*DynamicArray_##OBJNAME##_reserve) (DynamicArray_##OBJNAME *, int); \
void array_push_back(DynamicArray_##OBJNAME *ptr, OBJNAME object) { \
     if (ptr->capacity <= ptr->size) { \
          ptr->resize(ptr, ptr->capacity); \
     } \
     ptr->arr[ptr->size] = object; \
     ptr->size++; \
     } \
void array_resize(DynamicArray_##OBJNAME *ptr, int new_size) { \
     if (new_size >= ptr->capacity) { \
          ptr->arr = (OBJNAME *) realloc(ptr->arr, ((new_size + 10) * sizeof(OBJNAME))); \
          if(!(ptr->arr)) { \
               printf("Reallocation error in resize\n"); \
               exit(-1); \
               }\
          ptr->size = new_size; \
          ptr->capacity = new_size + 10; \
     } \
} \
OBJNAME & array_at(DynamicArray_##OBJNAME *ptr, int location) { \
     assert(location <= ptr->size); \
     return (ptr->arr[location]); \
} \
void array_reserve(DynamicArray_##OBJNAME *ptr, int reserved) {\
     if (reserved >= ptr->capacity) { \
          ptr->arr = (OBJNAME *)realloc(ptr->arr, ((reserved) * sizeof(OBJNAME))); \
          if (!(ptr->arr)) { \
               printf("Reallocation error in reserve\n"); \
               exit(-1); \
          }\
          ptr->capacity = reserved;\
     }\
}\
void array_delete(DynamicArray_##OBJNAME *ptr) { \
     free(ptr->arr); \
     free(ptr); \
}\
DynamicArray_##OBJNAME* DynamicArray_##OBJNAME##_new(){ \
     DynamicArray_##OBJNAME* ptr = (DynamicArray_##OBJNAME*) malloc(sizeof(DynamicArray_##OBJNAME)); \
     ptr->size = 0; \
     ptr->capacity = 10; \
     strcpy(ptr->type, "DynamicArray_"#OBJNAME); \
     ptr->arr = (OBJNAME*) malloc (sizeof(OBJNAME) * 10); \
     ptr->push_back = array_push_back; \
     ptr->resize = array_resize; \
     ptr->delet = array_delete; \
     ptr->at = array_at; \
     ptr->reserve = array_reserve; \
     DynamicArray_##OBJNAME##_at = array_at; \
     DynamicArray_##OBJNAME##_reserve = array_reserve; \
     return ptr; \
} \

#endif
