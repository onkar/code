#ifndef LIST_ANIMALPTR_HPP
#define LIST_ANIMALPTR_HPP
#include "Animals.hpp"

struct List_AnimalPtr_struct; 

struct List_AnimalPtr_Iterator_struct {
     List_AnimalPtr_struct *listptr;
     
     int (*equal)(List_AnimalPtr_Iterator_struct *, const List_AnimalPtr_Iterator_struct &);
     void (*next) (List_AnimalPtr_Iterator_struct *);
     Animal *(*deref) (List_AnimalPtr_Iterator_struct *);
};

typedef struct List_AnimalPtr_Iterator_struct List_AnimalPtr_Iterator;

struct List_AnimalPtr_struct {
     Animal *AnimalPtr;
     List_AnimalPtr_struct *next_Animal;

     void (*push_back) (struct List_AnimalPtr_struct *, Animal *);
     void (*dtor) (List_AnimalPtr_struct *);
     List_AnimalPtr_Iterator (*begin) (List_AnimalPtr_struct *);
     List_AnimalPtr_Iterator (*end) (List_AnimalPtr_struct *);
};

typedef struct List_AnimalPtr_struct List_AnimalPtr;

void List_AnimalPtr_ctor(List_AnimalPtr *);

#endif
